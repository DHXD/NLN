import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-farm',
  templateUrl: 'farm.html'  
})

export class FarmPage {

  constructor(public navCtrl: NavController) {
    
  }

}


