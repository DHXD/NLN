import { Component } from '@angular/core';

import { FarmIoT }    from './farm-iot';
import { FarmStock }  from './farm-stock'; 
import { FarmGAP }    from './farm-gap';


@Component({
  templateUrl: 'farm.html'
})
export class FarmPage {

  farmTab1Root = FarmIoT;
  farmTab2Root = FarmStock;
  farmTab3Root = FarmGAP;

  constructor() {

  }
} 