import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-farm-gap',
  templateUrl: 'farm-gap.html'  
})

export class FarmGAP {

  constructor(public navCtrl: NavController) {
    
  }

}


