import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-farm-iot',
  templateUrl: 'farm-iot.html'  
})

export class FarmIoT {

  constructor(public navCtrl: NavController) {
    
  }

}


