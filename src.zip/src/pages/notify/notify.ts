import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-notify',
  templateUrl: 'notify.html'
})

export class NotifyPage {

  constructor(public navCtrl: NavController) {

  }

}



