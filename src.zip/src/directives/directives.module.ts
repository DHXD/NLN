import { NgModule } from '@angular/core';
import { PreImgDirective } from './pre-img/pre-img';
@NgModule({
	declarations: [PreImgDirective],
	imports: [],
	exports: [PreImgDirective]
})
export class DirectivesModule {}
